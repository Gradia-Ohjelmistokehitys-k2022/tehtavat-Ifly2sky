﻿namespace T3.Model
{
    public class BitcoinData
    {
        public int Id { get; set; }
        public DateTime DateTime { get; set; }
        public decimal Price { get; set; }
        public decimal Market_cap { get; set; }
        public double Total_volume { get; set; }
    }
}
